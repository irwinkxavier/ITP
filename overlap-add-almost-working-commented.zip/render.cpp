/*
 ____  _____ _        _    
| __ )| ____| |      / \   
|  _ \|  _| | |     / _ \  
| |_) | |___| |___ / ___ \ 
|____/|_____|_____/_/   \_\

http://bela.io

C++ Real-Time Audio Programming with Bela - Lecture 18: Phase vocoder, part 1
fft-overlap-add-threads: overlap-add framework doing FFT in a low-priority thread
*/

#include <Bela.h>
#include <libraries/Fft/Fft.h>
#include <libraries/Scope/Scope.h>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <libraries/AudioFile/AudioFile.h>

// FFT-related variables
Fft signalFft;
Fft irFft;
Fft convFft;

const int gHopSize = 2048;	// How often we calculate a window
const int gFftSize = pow(2, ceil(log(2*gHopSize)/log(2)));	// FFT window size in samples

// Circular buffer and pointer for assembling a window of samples
const int gBufferSize = 4096;
std::vector<float> gInputBuffer(gBufferSize);
int gInputBufferPointer = 0;
int gHopCounter = 0;

int convLength;	//variable storing convolution length

// Circular buffer for collecting the output of the overlap-add process
std::vector<float> gOutputBuffer(gBufferSize);
int gOutputBufferWritePointer = 2*gHopSize;	// Need one extra hop of latency to run FFT in second thread
int gOutputBufferReadPointer = 0;

// Name of the sound file (in project folder)
std::string gFilename = "click.wav";
bool fileEnd = false;

// array to store IR
std::vector<float> gImpulseBuffer;

// Bela oscilloscope
Scope gScope;

// Thread for FFT processing
AuxiliaryTask gFftTask;
int gCachedInputBufferPointer = 0;

void process_fft_background(void *);

bool setup(BelaContext *context, void *userData)
{
	
	gImpulseBuffer = AudioFileUtilities::loadMono(gFilename);	//load IR
	
	convLength = (ceil((float) 8192/gHopSize))*gHopSize + (gFftSize - gHopSize);	//calculate convolution length
	
	//zero-pad IR if necessary
	if(gImpulseBuffer.size()%gHopSize != 0)
	{
		for(int i = 0; i < (gHopSize-gImpulseBuffer.size()%gHopSize); i++)
		{
			gImpulseBuffer.push_back(0);
		}
	}
	
	// Set up the FFT and its buffers
	signalFft.setup(gFftSize);
	irFft.setup(gFftSize);
	convFft.setup(gFftSize);

	// Initialise the scope
	gScope.setup(2, context->audioSampleRate);
	
	// Set up the thread for the FFT
	gFftTask = Bela_createAuxiliaryTask(process_fft_background, 50, "bela-process-fft");

	return true;
}

// This function handles the FFT processing in this example once the buffer has
// been assembled.

void process_fft(std::vector<float> const& inBuffer, unsigned int inPointer, std::vector<float>& outBuffer, unsigned int outPointer, std::vector<float>& impulseBuffer)
{
	std::vector<float> unwrappedBuffer(gFftSize);	//array to hold the unwrapped input
	std::vector<float> convolvedOut(convLength);	//array to hold the combined out
	std::vector<float> FftImpulseBuffer(gFftSize);	//array to hold the impulse partition
	
	//Init pointers for the above arrays
	int combinedOutPointer = 0;
	int convolvedOutPointer = 0;
	int impulseBufferPointer = 0;
	
	// Copy buffer into FFT input, starting one window ago
	for(int n = 0; n < gHopSize; n++) {
		// Use modulo arithmetic to calculate the circular buffer index
		int circularBufferIndex = (inPointer + n - gFftSize + gBufferSize) % gBufferSize;
		unwrappedBuffer[n] = inBuffer[circularBufferIndex];
	}

	signalFft.fft(unwrappedBuffer);		//perform FFT on signal

	//Overlap-Add Partitioned Conv loop
	while(!fileEnd)		//while end of IR is not reached
	{
		//Copy IR partition to the array
		for(int i = 0; i < gHopSize; i++)
		{
			FftImpulseBuffer[i] = impulseBuffer[impulseBufferPointer + i];
		}
		//Update IR partition pointer
		if(impulseBufferPointer + gHopSize >= 8192)		//IR length set to 8192 as an example
		{
			fileEnd = true;		//end of file true
			impulseBufferPointer = 0;		//reset IR pointer
		}
		else
		{
			impulseBufferPointer+=gHopSize;		//increment pointer to start at next partition
		}
		
		irFft.fft(FftImpulseBuffer);		//Perform FFT on IR partition
			
		//Convolution
		for(int n = 0; n < gFftSize; n++) {
			convFft.fdr(n) = (signalFft.fdr(n) * irFft.fdr(n)) - (signalFft.fdi(n) * irFft.fdi(n));
			convFft.fdi(n) = (signalFft.fdr(n) * irFft.fdi(n)) + (signalFft.fdi(n) * irFft.fdr(n));
		}
			
		// Run the inverse FFT
		convFft.ifft();
		
		//overlap-add partly convolved out to convolvedOut
		for(int n = 0; n < gFftSize; n++)
		{
			convolvedOut[combinedOutPointer+n] += convFft.td(n);
		}
		//Update combinedOutPointer
		combinedOutPointer+=gHopSize;
	}
	fileEnd = false;
	
	// Add the combined output into the output buffer starting at the write pointer
	for(int n = 0; n < gHopSize; n++) {
		int circularBufferIndex = (outPointer + n) % gBufferSize;
		outBuffer[circularBufferIndex]  = convolvedOut[convolvedOutPointer + n];
		convolvedOut[convolvedOutPointer + n] = 0;		//reset convolvedOut element for next overlap-add
	}
	
	//Update convolvedOutPointer
	convolvedOutPointer+=gHopSize;
	if(convolvedOutPointer >= convLength)
	{
		convolvedOutPointer = 0;
	}
}

// This function runs in an auxiliary task on Bela, calling process_fft
void process_fft_background(void *)
{
	//call process_fft()
	process_fft(gInputBuffer, gCachedInputBufferPointer, gOutputBuffer, gOutputBufferWritePointer, gImpulseBuffer);
	//update the output buffer write pointer to start at the next hop
	gOutputBufferWritePointer = (gOutputBufferWritePointer + gHopSize) % gBufferSize;
}

void render(BelaContext *context, void *userData)
{
	for(unsigned int n = 0; n < context->audioFrames; n++) {
        // Read the next sample from the buffer
        float in = audioRead(context, n, 0);

		// Store the sample ("in") in a buffer for the FFT
		// Increment the pointer and when full window has been 
		// assembled, call process_fft()
		gInputBuffer[gInputBufferPointer++] = in;
		if(gInputBufferPointer >= gBufferSize) {
			// Wrap the circular buffer
			// Notice: this is not the condition for starting a new FFT
			gInputBufferPointer = 0;
		}
		
		// Get the output sample from the output buffer
		float out = gOutputBuffer[gOutputBufferReadPointer];
		
		// Then clear the output sample in the buffer so it is ready for the next overlap-add
		gOutputBuffer[gOutputBufferReadPointer] = 0;
		
		// Scale the output down by the overlap factor (e.g. how many windows overlap per sample?)
		//out *= (float)gHopSize / (float)gFftSize;
		
		// Increment the read pointer in the output cicular buffer
		gOutputBufferReadPointer++;
		if(gOutputBufferReadPointer >= gBufferSize)
			gOutputBufferReadPointer = 0;
		
		// Increment the hop counter and start a new FFT if we've reached the hop size
		if(++gHopCounter >= gHopSize) {
			gHopCounter = 0;
			gCachedInputBufferPointer = gInputBufferPointer;
			Bela_scheduleAuxiliaryTask(gFftTask);
		}

		// Write the audio input to left channel, output to the right channel, both to the scope
		audioWrite(context, n, 0, in);
		audioWrite(context, n, 1, out);
		gScope.log(in, out);
	}
}

void cleanup(BelaContext *context, void *userData)
{

}
